[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [SetTitleActivity](index.md) / [exerciseNum](./exercise-num.md)

# exerciseNum

`var exerciseNum: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)