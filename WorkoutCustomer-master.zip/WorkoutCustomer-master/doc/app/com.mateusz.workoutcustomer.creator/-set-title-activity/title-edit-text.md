[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [SetTitleActivity](index.md) / [titleEditText](./title-edit-text.md)

# titleEditText

`lateinit var titleEditText: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user can put data for new workout

### Property

`titleEditText` - is EditText where user can put data for new workout