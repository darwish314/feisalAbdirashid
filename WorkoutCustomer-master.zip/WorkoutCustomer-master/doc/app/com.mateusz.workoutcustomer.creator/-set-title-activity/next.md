[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [SetTitleActivity](index.md) / [next](./next.md)

# next

`fun next(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It checks EditTexts not empty and data is too long.
If no it create new intent, put data and start it

