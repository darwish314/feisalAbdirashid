[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [SetTitleActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SetTitleActivity()`

It creates new Workout

