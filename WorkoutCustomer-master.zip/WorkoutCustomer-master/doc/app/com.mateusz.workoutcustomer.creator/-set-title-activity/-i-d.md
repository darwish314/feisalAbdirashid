[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [SetTitleActivity](index.md) / [ID](./-i-d.md)

# ID

`const val ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address title workout id where new intent put data. And where next activity can find data from this activity. Next activity use ID for create new Exercise to this workout

### Property

`ID` - is address title workout id where new intent put data. And where next activity can find data from this activity. Next activity use ID for create new Exercise to this workout

**Author**
Mateusz Karłowski

