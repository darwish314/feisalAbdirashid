[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [DESCRIPTION_WORKOUT](./-d-e-s-c-r-i-p-t-i-o-n_-w-o-r-k-o-u-t.md)

# DESCRIPTION_WORKOUT

`val DESCRIPTION_WORKOUT: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)