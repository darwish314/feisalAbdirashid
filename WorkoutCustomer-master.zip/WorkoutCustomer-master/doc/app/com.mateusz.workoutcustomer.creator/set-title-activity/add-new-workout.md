[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [addNewWorkout](./add-new-workout.md)

# addNewWorkout

`fun addNewWorkout(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)