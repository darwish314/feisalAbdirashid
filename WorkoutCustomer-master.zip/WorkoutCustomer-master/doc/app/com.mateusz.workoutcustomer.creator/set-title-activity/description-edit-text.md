[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [descriptionEditText](./description-edit-text.md)

# descriptionEditText

`lateinit var descriptionEditText: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)