[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`setTitleActivity()`