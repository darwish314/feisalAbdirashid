[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [titleEditText](./title-edit-text.md)

# titleEditText

`lateinit var titleEditText: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)