[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [setTitleActivity](index.md) / [TITTLE_WORKOUT](./-t-i-t-t-l-e_-w-o-r-k-o-u-t.md)

# TITTLE_WORKOUT

`val TITTLE_WORKOUT: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)