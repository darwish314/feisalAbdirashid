[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseActivity()`

class ExerciseActivity is create new Exercise

