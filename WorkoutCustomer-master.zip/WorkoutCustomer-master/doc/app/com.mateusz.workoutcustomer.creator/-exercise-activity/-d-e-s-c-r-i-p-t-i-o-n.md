[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [DESCRIPTION](./-d-e-s-c-r-i-p-t-i-o-n.md)

# DESCRIPTION

`const val DESCRIPTION: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address description new exercise where new intent put data. And where next activity can find data from this activity

### Property

`DESCRIPTION` - is address description new exercise where new intent put data. And where next activity can find data from this activity