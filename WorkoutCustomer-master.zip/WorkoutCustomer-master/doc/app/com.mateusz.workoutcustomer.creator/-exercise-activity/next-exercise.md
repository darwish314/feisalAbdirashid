[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [nextExercise](./next-exercise.md)

# nextExercise

`fun nextExercise(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It checks EditText is empty. If yes show statement. But if EditText is not empty. It create new Intent, put data and start new activity

