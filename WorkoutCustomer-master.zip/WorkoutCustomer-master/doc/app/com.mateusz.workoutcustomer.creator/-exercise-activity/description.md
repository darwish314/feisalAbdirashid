[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [description](./description.md)

# description

`lateinit var description: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put description new exercise

### Property

`description` - is EditText where user put description new exercise