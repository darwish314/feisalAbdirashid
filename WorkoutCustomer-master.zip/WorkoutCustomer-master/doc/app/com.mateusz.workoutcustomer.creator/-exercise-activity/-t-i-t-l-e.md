[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [TITLE](./-t-i-t-l-e.md)

# TITLE

`const val TITLE: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address title new exercise where new intent put data. And where next activity can find data from this activity

### Property

`TITLE` - is address title new exercise where new intent put data. And where next activity can find data from this activity