[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [onBackPressed](./on-back-pressed.md)

# onBackPressed

`fun onBackPressed(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It shows dialog with message "Are you sure you want to exit?"
This dialog have two options
YES retreat
NO do nothing

