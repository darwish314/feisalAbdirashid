[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [title](./title.md)

# title

`lateinit var title: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put title new exercise

### Property

`title` - is EditText where user put title new exercise