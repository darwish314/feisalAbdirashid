[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [onCreate](./on-create.md)

# onCreate

`protected fun onCreate(savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

it finds layout elements and stores to variable

