[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [INSTRUCTION](./-i-n-s-t-r-u-c-t-i-o-n.md)

# INSTRUCTION

`const val INSTRUCTION: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address instruction new exercise where new intent put data. And where next activity can find data from this activity

### Property

`INSTRUCTION` - is address instruction new exercise where new intent put data. And where next activity can find data from this activity

**Author**
Mateusz Karłowski

