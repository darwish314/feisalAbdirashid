[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [radioGroup](./radio-group.md)

# radioGroup

`lateinit var radioGroup: `[`RadioGroup`](https://developer.android.com/reference/android/widget/RadioGroup.html)

is group with two RadioButtons. First is Time. Second is Repeat. User choose button according from exercise

### Property

`radioGroup` - is group with two RadioButtons. First is Time. Second is Repeat. User choose button according from exercise