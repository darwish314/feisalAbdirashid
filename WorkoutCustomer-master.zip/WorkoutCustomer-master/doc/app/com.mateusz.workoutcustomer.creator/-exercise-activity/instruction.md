[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [ExerciseActivity](index.md) / [instruction](./instruction.md)

# instruction

`lateinit var instruction: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put instruction new exercise

### Property

`instruction` - is EditText where user put instruction new exercise