[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`RepeatActivity()`

RepeatActivity is creator repeat exercise

