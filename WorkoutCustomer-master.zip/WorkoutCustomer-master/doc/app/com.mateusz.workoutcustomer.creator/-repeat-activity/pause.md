[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [pause](./pause.md)

# pause

`lateinit var pause: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put pause number new exercise

### Property

`pause` - is EditText where user put pause number new exercise