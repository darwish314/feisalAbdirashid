[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [spinner](./spinner.md)

# spinner

`lateinit var spinner: `[`Spinner`](https://developer.android.com/reference/android/widget/Spinner.html)