[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [addExerciseRepeat](./add-exercise-repeat.md)

# addExerciseRepeat

`fun addExerciseRepeat(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

check EditText is not empty, evokes add and create new intent and start it

