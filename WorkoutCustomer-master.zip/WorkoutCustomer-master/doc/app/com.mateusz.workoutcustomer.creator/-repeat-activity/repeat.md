[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [repeat](./repeat.md)

# repeat

`lateinit var repeat: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put repeat number new exercise

### Property

`repeat` - is EditText where user put repeat number new exercise