[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [series](./series.md)

# series

`lateinit var series: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)

is EditText where user put series number new exercise

### Property

`series` - is EditText where user put series number new exercise