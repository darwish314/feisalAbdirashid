[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [RepeatActivity](index.md) / [onBackPressed](./on-back-pressed.md)

# onBackPressed

`fun onBackPressed(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It shows dialog window with message "Are you sure you want to not save this exercise?"
It has 2 options:
YES back to MenuActivity
NO do nothing

