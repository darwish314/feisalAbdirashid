[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [TimeActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`TimeActivity()`

RepeatActivity is creator repeat exercise

