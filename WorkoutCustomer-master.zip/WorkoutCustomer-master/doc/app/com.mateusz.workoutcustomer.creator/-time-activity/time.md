[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [TimeActivity](index.md) / [time](./time.md)

# time

`lateinit var time: `[`EditText`](https://developer.android.com/reference/android/widget/EditText.html)