[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [TimeActivity](index.md) / [spinnerPause](./spinner-pause.md)

# spinnerPause

`lateinit var spinnerPause: `[`Spinner`](https://developer.android.com/reference/android/widget/Spinner.html)