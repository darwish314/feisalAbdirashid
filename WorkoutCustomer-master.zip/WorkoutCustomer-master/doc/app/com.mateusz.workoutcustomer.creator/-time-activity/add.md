[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [TimeActivity](index.md) / [add](./add.md)

# add

`fun add(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It adds new Exercise to database for this get data from intent and EditText

