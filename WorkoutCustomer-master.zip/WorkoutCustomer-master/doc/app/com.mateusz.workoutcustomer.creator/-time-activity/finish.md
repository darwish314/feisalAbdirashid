[app](../../index.md) / [com.mateusz.workoutcustomer.creator](../index.md) / [TimeActivity](index.md) / [finish](./finish.md)

# finish

`fun finish(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

check EditText is not empty, evokes add and finish activity

