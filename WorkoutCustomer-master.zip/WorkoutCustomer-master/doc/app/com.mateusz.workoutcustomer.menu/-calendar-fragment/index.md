[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [CalendarFragment](./index.md)

# CalendarFragment

`class CalendarFragment : Fragment`

class CalendarFragment only show layout R.layout.fragment_settings

**Author**
Mateusz Karłowski

### Constructors

| [&lt;init&gt;](-init-.md) | `CalendarFragment()`<br>class CalendarFragment only show layout R.layout.fragment_settings |

### Functions

| [onCreateView](on-create-view.md) | `fun onCreateView(inflater: `[`LayoutInflater`](https://developer.android.com/reference/android/view/LayoutInflater.html)`, container: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`?, savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`View`](https://developer.android.com/reference/android/view/View.html)`?` |

