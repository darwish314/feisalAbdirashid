[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [CalendarFragment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`CalendarFragment()`

class CalendarFragment only show layout R.layout.fragment_settings

**Author**
Mateusz Karłowski

