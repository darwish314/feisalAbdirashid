[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MenuActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`MenuActivity()`

A class MenuActivity is Main Activity in my App

**Author**
Mateusz Karłowski

