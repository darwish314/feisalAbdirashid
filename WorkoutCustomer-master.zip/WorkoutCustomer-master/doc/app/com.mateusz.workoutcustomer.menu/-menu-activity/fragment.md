[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MenuActivity](index.md) / [fragment](./fragment.md)

# fragment

`lateinit var fragment: Fragment`