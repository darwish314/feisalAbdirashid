[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MenuActivity](index.md) / [loadFragment](./load-fragment.md)

# loadFragment

`fun loadFragment(fragment: Fragment?): `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Function loadFragment start new Fragment in the part of the Layout

