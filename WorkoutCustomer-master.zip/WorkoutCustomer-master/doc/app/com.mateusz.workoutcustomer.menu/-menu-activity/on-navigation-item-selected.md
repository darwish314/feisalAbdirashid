[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MenuActivity](index.md) / [onNavigationItemSelected](./on-navigation-item-selected.md)

# onNavigationItemSelected

`fun onNavigationItemSelected(item: `[`MenuItem`](https://developer.android.com/reference/android/view/MenuItem.html)`): `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)