[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MenuActivity](index.md) / [fab](./fab.md)

# fab

`lateinit var fab: FloatingActionButton`

Function onNavigationItemSelected change fragments when user chosen option on BottomNavigationView

