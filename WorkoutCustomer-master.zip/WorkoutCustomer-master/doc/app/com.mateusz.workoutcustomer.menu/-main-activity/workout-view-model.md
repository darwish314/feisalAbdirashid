[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MainActivity](index.md) / [workoutViewModel](./workout-view-model.md)

# workoutViewModel

`lateinit var workoutViewModel: `[`WorkoutViewModel`](../../com.mateusz.workoutcustomer.database/-workout-view-model/index.md)

is object class WorkoutViewModel

### Property

`workoutViewModel` - is object class WorkoutViewModel

**See Also**

[WorkoutViewModel](../../com.mateusz.workoutcustomer.database/-workout-view-model/index.md)

