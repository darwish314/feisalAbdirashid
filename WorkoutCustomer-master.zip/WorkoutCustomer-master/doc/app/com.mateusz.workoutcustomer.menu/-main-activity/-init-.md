[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MainActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`MainActivity()`

MainActivity is splash screen
It shows  on 0.7 seconds layout activity_welcom and switch to MenuActivity

**Author**
Mateusz Karłowski

