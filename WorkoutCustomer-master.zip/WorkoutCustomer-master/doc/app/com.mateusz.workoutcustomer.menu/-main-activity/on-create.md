[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [MainActivity](index.md) / [onCreate](./on-create.md)

# onCreate

`protected fun onCreate(savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

onCreate create WorkoutViewModel and ready other data in database.
The second task onCreate is stop splash screen on 7 seconds

