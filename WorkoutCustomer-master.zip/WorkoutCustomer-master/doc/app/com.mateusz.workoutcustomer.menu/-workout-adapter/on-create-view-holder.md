[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [WorkoutAdapter](index.md) / [onCreateViewHolder](./on-create-view-holder.md)

# onCreateViewHolder

`fun onCreateViewHolder(parent: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`, p1: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`WorkoutViewHolder`](-workout-view-holder/index.md)

onCreateViewHolder find CardView in layout and return items look like R.layout.workout_item with data

