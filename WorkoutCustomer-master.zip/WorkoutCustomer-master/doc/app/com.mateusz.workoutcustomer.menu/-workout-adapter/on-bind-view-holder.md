[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [WorkoutAdapter](index.md) / [onBindViewHolder](./on-bind-view-holder.md)

# onBindViewHolder

`fun onBindViewHolder(holder: `[`WorkoutViewHolder`](-workout-view-holder/index.md)`, positon: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

onBindViewHolder set data from mWorkout to item

