[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [WorkoutAdapter](index.md) / [getItemCount](./get-item-count.md)

# getItemCount

`fun getItemCount(): `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

**Return**
how many item

