[app](../../../index.md) / [com.mateusz.workoutcustomer.menu](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [onClick](./on-click.md)

# onClick

`fun onClick(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

onClick starts new Intent and put ID to this Intent

