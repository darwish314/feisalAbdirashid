[app](../../../index.md) / [com.mateusz.workoutcustomer.menu](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [mWorkoutTitle](./m-workout-title.md)

# mWorkoutTitle

`var mWorkoutTitle: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)

is TextView with workout Title, Its id is R.id.workout_title

### Property

`mWorkoutTitle` - is TextView with workout Title, Its id is R.id.workout_title