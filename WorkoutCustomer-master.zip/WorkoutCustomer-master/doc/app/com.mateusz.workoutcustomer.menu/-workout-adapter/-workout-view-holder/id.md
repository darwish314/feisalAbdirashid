[app](../../../index.md) / [com.mateusz.workoutcustomer.menu](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [id](./id.md)

# id

`var id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

is workout id

### Property

`id` - is workout id