[app](../../../index.md) / [com.mateusz.workoutcustomer.menu](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [mAdapter](./m-adapter.md)

# mAdapter

`var mAdapter: `[`WorkoutAdapter`](../index.md)