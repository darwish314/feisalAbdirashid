[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [NotifyFragment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`NotifyFragment()`