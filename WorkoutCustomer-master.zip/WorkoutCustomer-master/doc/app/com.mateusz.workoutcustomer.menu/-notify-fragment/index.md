[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [NotifyFragment](./index.md)

# NotifyFragment

`class NotifyFragment : Fragment`

### Constructors

| [&lt;init&gt;](-init-.md) | `NotifyFragment()` |

### Functions

| [onCreateView](on-create-view.md) | `fun onCreateView(inflater: `[`LayoutInflater`](https://developer.android.com/reference/android/view/LayoutInflater.html)`, container: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`?, savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`View`](https://developer.android.com/reference/android/view/View.html)`?` |

