[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [SettingsFragment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SettingsFragment()`

class SettingsFragment only show layout R.layout.fragment_settings

**Author**
Mateusz Karłowski

