[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [SettingsFragment](./index.md)

# SettingsFragment

`class SettingsFragment : Fragment`

class SettingsFragment only show layout R.layout.fragment_settings

**Author**
Mateusz Karłowski

### Constructors

| [&lt;init&gt;](-init-.md) | `SettingsFragment()`<br>class SettingsFragment only show layout R.layout.fragment_settings |

### Functions

| [onCreateView](on-create-view.md) | `fun onCreateView(inflater: `[`LayoutInflater`](https://developer.android.com/reference/android/view/LayoutInflater.html)`, container: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`?, savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`View`](https://developer.android.com/reference/android/view/View.html)`?` |

