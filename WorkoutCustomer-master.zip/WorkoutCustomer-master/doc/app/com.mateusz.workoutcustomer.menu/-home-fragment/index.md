[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [HomeFragment](./index.md)

# HomeFragment

`class HomeFragment : Fragment`

class HomeFragment is for this display layout R.layout.fragment_home
also it reads old data to CardView

### Constructors

| [&lt;init&gt;](-init-.md) | `HomeFragment()`<br>class HomeFragment is for this display layout R.layout.fragment_home also it reads old data to CardView |

### Functions

| [onCreateView](on-create-view.md) | `fun onCreateView(inflater: `[`LayoutInflater`](https://developer.android.com/reference/android/view/LayoutInflater.html)`, container: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`?, savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`View`](https://developer.android.com/reference/android/view/View.html)`?`<br>onCreateView find recyclerView set adapter and LayoutManager finally get data from database and set as data for RecycleView |

