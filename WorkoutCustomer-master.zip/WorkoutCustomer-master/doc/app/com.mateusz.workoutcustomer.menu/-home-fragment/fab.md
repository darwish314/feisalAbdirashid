[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [HomeFragment](index.md) / [fab](./fab.md)

# fab

`lateinit var fab: FloatingActionButton`