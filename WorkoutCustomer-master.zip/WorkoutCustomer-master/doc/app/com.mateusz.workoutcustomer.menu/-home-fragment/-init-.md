[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [HomeFragment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`HomeFragment()`

class HomeFragment is for this display layout R.layout.fragment_home
also it reads old data to CardView

