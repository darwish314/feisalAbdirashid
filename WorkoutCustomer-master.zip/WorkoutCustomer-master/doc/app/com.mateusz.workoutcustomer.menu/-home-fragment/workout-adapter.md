[app](../../index.md) / [com.mateusz.workoutcustomer.menu](../index.md) / [HomeFragment](index.md) / [workoutAdapter](./workout-adapter.md)

# workoutAdapter

`lateinit var workoutAdapter: `[`WorkoutAdapter`](../../com.mateusz.workoutcustomer.database/-workout-adapter/index.md)