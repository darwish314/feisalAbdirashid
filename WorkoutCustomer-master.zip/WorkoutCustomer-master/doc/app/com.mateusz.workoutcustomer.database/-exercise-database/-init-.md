[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDatabase](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseDatabase()`

It opens data, This class is singleton

**Author**
Mateusz Karłowski

