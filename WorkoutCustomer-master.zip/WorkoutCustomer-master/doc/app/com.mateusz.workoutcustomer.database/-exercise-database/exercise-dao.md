[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDatabase](index.md) / [exerciseDao](./exercise-dao.md)

# exerciseDao

`abstract fun exerciseDao(): `[`ExerciseDao`](../-exercise-dao/index.md)