[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDatabase](index.md) / [getDatabase](./get-database.md)

# getDatabase

`fun getDatabase(context: `[`Context`](https://developer.android.com/reference/android/content/Context.html)`, scope: CoroutineScope): `[`ExerciseDatabase`](index.md)

Singleton implementation and open database

