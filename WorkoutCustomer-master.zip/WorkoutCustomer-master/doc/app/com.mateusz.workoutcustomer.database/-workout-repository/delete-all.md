[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutRepository](index.md) / [deleteAll](./delete-all.md)

# deleteAll

`@WorkerThread suspend fun deleteAll(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)