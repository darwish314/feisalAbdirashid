[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutRepository](index.md) / [updateWorkoutDescription](./update-workout-description.md)

# updateWorkoutDescription

`@WorkerThread suspend fun updateWorkoutDescription(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)