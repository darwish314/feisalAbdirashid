[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutRepository](index.md) / [allWorkout](./all-workout.md)

# allWorkout

`var allWorkout: LiveData<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Workout`](../-workout/index.md)`>>`

has all workour

### Property

`allWorkout` - has all workour

**Author**
Mateusz Karłowski

