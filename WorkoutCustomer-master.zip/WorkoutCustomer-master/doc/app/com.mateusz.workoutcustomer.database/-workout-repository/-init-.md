[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutRepository](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WorkoutRepository(workoutDao: `[`WorkoutDao`](../-workout-dao/index.md)`)`

Workout Reposority is class contain

