[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutRepository](index.md) / [deleteById](./delete-by-id.md)

# deleteById

`@WorkerThread suspend fun deleteById(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)