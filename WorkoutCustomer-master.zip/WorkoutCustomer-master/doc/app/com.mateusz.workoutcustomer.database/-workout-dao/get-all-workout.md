[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [getAllWorkout](./get-all-workout.md)

# getAllWorkout

`abstract fun getAllWorkout(): LiveData<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Workout`](../-workout/index.md)`>>`

Function **getAllWords** get all words form data

**Return**
return LiveData&lt;List&gt; form database

