[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [updateWorkoutTitle](./update-workout-title.md)

# updateWorkoutTitle

`abstract fun updateWorkoutTitle(title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ID: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)