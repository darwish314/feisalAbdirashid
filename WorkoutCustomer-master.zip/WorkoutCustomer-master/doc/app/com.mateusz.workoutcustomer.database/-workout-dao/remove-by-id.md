[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [removeById](./remove-by-id.md)

# removeById

`abstract fun removeById(ID: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Function **removeById** remove workout with the same id

