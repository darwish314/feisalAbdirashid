[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [getFromId](./get-from-id.md)

# getFromId

`abstract fun getFromId(index: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Workout`](../-workout/index.md)