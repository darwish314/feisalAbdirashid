[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [deleteAll](./delete-all.md)

# deleteAll

`abstract fun deleteAll(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Function **deleteAll** delete all data in database

