[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDao](index.md) / [insert](./insert.md)

# insert

`abstract fun insert(workout: `[`Workout`](../-workout/index.md)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Function **insert** insert data to database

