[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDao](index.md) / [deleteByExerciseId](./delete-by-exercise-id.md)

# deleteByExerciseId

`abstract fun deleteByExerciseId(index: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Delete by exercise id

