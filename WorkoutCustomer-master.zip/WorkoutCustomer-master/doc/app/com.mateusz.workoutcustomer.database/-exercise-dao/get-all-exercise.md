[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDao](index.md) / [getAllExercise](./get-all-exercise.md)

# getAllExercise

`abstract fun getAllExercise(): LiveData<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Exercise`](../-exercise/index.md)`>>`

Get all exercise

