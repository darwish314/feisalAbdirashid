[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDao](index.md) / [insert](./insert.md)

# insert

`abstract fun insert(exercise: `[`Exercise`](../-exercise/index.md)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Insert new exercise

