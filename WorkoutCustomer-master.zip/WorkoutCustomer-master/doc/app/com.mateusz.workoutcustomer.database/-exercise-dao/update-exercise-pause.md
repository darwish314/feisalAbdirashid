[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDao](index.md) / [updateExercisePause](./update-exercise-pause.md)

# updateExercisePause

`abstract fun updateExercisePause(pause: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, ID: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)