[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseDao](index.md) / [updateExerciseTitle](./update-exercise-title.md)

# updateExerciseTitle

`abstract fun updateExerciseTitle(title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ID: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)