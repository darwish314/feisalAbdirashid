[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseRepository](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseRepository(exerciseDao: `[`ExerciseDao`](../-exercise-dao/index.md)`)`

This class have functions evokes other function from ExerciseDao

**Author**
Mateusz Karłowski

