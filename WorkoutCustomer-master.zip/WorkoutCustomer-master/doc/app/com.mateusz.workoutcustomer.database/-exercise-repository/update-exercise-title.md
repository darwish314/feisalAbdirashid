[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseRepository](index.md) / [updateExerciseTitle](./update-exercise-title.md)

# updateExerciseTitle

`@WorkerThread suspend fun updateExerciseTitle(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)