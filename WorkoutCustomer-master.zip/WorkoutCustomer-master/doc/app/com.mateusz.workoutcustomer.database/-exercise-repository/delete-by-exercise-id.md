[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseRepository](index.md) / [deleteByExerciseId](./delete-by-exercise-id.md)

# deleteByExerciseId

`@WorkerThread suspend fun deleteByExerciseId(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

Delete all element the same exercise ID

