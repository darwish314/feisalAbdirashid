[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [ExerciseRepository](index.md) / [updateExercisePauseFormat](./update-exercise-pause-format.md)

# updateExercisePauseFormat

`@WorkerThread suspend fun updateExercisePauseFormat(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, pauseFormat: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)