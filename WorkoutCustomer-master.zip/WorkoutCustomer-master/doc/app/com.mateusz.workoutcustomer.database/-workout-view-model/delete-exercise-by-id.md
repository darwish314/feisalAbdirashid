[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [deleteExerciseById](./delete-exercise-by-id.md)

# deleteExerciseById

`fun deleteExerciseById(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): Job`

Function delete exercise by ID

