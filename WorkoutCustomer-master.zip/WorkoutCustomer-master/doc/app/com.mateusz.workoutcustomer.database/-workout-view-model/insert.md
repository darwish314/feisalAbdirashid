[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [insert](./insert.md)

# insert

`fun insert(workout: `[`Workout`](../-workout/index.md)`): Job`

function **insert** insert Workout to database

`fun insert(exercise: `[`Exercise`](../-exercise/index.md)`): Job`

function insert insert exercise to database

