[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WorkoutViewModel(application: `[`Application`](https://developer.android.com/reference/android/app/Application.html)`)`

get repository and allWorkout

**Constructor**
get repository and allWorkout

**Author**
Mateusz Karłowski

