[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [findExerciseById](./find-exercise-by-id.md)

# findExerciseById

`fun findExerciseById(index: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Exercise`](../-exercise/index.md)

Function find exercise by ID

