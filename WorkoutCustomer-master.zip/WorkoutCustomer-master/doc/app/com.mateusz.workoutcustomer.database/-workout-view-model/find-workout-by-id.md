[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [findWorkoutById](./find-workout-by-id.md)

# findWorkoutById

`fun findWorkoutById(index: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Workout`](../-workout/index.md)

Function find workout by ID

