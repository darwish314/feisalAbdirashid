[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [deleteAll](./delete-all.md)

# deleteAll

`fun deleteAll(): Job`

Function delete all data

