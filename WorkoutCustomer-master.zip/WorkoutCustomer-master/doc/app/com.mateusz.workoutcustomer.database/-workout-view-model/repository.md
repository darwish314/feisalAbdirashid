[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [repository](./repository.md)

# repository

`var repository: `[`WorkoutRepository`](../-workout-repository/index.md)

is var repository

### Property

`repository` - is var repository