[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [repositoryExercise](./repository-exercise.md)

# repositoryExercise

`var repositoryExercise: `[`ExerciseRepository`](../-exercise-repository/index.md)

is var repository with exercise and function

### Property

`repositoryExercise` - is var repository with exercise and function