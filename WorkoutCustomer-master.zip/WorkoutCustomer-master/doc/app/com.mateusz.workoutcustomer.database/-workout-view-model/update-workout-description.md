[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutViewModel](index.md) / [updateWorkoutDescription](./update-workout-description.md)

# updateWorkoutDescription

`fun updateWorkoutDescription(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): Job`