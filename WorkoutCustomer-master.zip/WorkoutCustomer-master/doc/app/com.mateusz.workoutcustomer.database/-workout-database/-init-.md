[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDatabase](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WorkoutDatabase()`

class **WorkoutDatabase** is singleton for build and open database

**Author**
Mateusz Karłowski

