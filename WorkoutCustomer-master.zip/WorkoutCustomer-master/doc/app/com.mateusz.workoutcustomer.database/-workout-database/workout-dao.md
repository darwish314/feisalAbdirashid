[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDatabase](index.md) / [workoutDao](./workout-dao.md)

# workoutDao

`abstract fun workoutDao(): `[`WorkoutDao`](../-workout-dao/index.md)

Abstract fun

**Return**
WorkoutDao

