[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutDatabase](index.md) / [getDatabase](./get-database.md)

# getDatabase

`fun getDatabase(context: `[`Context`](https://developer.android.com/reference/android/content/Context.html)`, scope: CoroutineScope): `[`WorkoutDatabase`](index.md)

Singleton implementation and open database

