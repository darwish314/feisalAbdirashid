[app](../../../index.md) / [com.mateusz.workoutcustomer.database](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [mWorkoutDescripton](./m-workout-descripton.md)

# mWorkoutDescripton

`var mWorkoutDescripton: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)