[app](../../../index.md) / [com.mateusz.workoutcustomer.database](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WorkoutViewHolder(viewItem: `[`View`](https://developer.android.com/reference/android/view/View.html)`, workoutAdapter: `[`WorkoutAdapter`](../index.md)`)`

set OnClick as OnClickListener

**Constructor**
set OnClick as OnClickListener

