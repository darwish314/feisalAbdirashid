[app](../../../index.md) / [com.mateusz.workoutcustomer.database](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [mWorkoutTitile](./m-workout-titile.md)

# mWorkoutTitile

`var mWorkoutTitile: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)