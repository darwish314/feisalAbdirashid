[app](../../../index.md) / [com.mateusz.workoutcustomer.database](../../index.md) / [WorkoutAdapter](../index.md) / [WorkoutViewHolder](index.md) / [mWorkoutDescription](./m-workout-description.md)

# mWorkoutDescription

`var mWorkoutDescription: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)

is TextView with workout Description. Its id is R.id.workout_description

### Property

`mWorkoutDescription` - is TextView with workout Description. Its id is R.id.workout_description