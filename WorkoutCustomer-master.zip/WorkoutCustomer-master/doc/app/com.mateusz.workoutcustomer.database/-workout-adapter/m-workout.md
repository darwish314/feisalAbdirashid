[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutAdapter](index.md) / [mWorkout](./m-workout.md)

# mWorkout

`lateinit var mWorkout: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Workout`](../-workout/index.md)`>`