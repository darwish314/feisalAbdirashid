[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutAdapter](index.md) / [addElement](./add-element.md)

# addElement

`fun addElement(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)