[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [WorkoutAdapter](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WorkoutAdapter(context: `[`Context`](https://developer.android.com/reference/android/content/Context.html)`)`

class WorkoutAdapter extends from RecycleView.Adapter and it is for RecycleView

