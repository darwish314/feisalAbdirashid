[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Workout](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Workout(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

A data class *workout* use for database SQLLite

