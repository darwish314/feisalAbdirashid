[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Exercise](index.md) / [pauseFormat](./pause-format.md)

# pauseFormat

`var pauseFormat: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)