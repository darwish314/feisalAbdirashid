[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Exercise](index.md) / [description](./description.md)

# description

`var description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)