[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Exercise](index.md) / [title](./title.md)

# title

`var title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)