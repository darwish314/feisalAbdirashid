[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Exercise](index.md) / [workoutId](./workout-id.md)

# workoutId

`var workoutId: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)