[app](../../index.md) / [com.mateusz.workoutcustomer.database](../index.md) / [Exercise](index.md) / [pause](./pause.md)

# pause

`var pause: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)