[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ViewActivity](index.md) / [WORKOUTID](./-w-o-r-k-o-u-t-i-d.md)

# WORKOUTID

`const val WORKOUTID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address where intent put data about id and where activity get data.

### Property

`WORKOUTID` - is address where intent put data about id and where activity get data.

**Author**
Mateusz Karłowski

