[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ViewActivity](index.md) / [onCreate](./on-create.md)

# onCreate

`protected fun onCreate(savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

It gets id from intent. Next find workout by id in database. And print about workout info on TextView.
It gets all exercise this workout and set in Adapter. Last recycleView set  adapter

