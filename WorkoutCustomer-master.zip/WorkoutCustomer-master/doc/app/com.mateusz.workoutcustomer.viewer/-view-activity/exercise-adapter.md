[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ViewActivity](index.md) / [exerciseAdapter](./exercise-adapter.md)

# exerciseAdapter

`lateinit var exerciseAdapter: `[`ExerciseAdapter`](../-exercise-adapter/index.md)

is object ExerciseAdapter for RecycleView

### Property

`exerciseAdapter` - is object ExerciseAdapter for RecycleView

**See Also**

[exerciseAdapter](./exercise-adapter.md)

