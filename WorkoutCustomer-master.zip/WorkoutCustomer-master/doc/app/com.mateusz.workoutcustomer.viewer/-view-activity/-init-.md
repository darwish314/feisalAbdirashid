[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ViewActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ViewActivity()`

This class is main viewer workout

