[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ViewActivity](index.md) / [workoutId](./workout-id.md)

# workoutId

`var workoutId: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)