[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [StartActivity](index.md) / [position](./position.md)

# position

`var position: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)