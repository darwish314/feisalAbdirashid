[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [StartActivity](index.md) / [close](./close.md)

# close

`var close: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)