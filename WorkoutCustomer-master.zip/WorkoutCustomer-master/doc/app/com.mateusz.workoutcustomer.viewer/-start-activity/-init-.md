[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [StartActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`StartActivity()`

This class has workout all Exercise and counting down to start workout.

**Author**
Mateusz Karłowski

