[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [StartActivity](index.md) / [series](./series.md)

# series

`var series: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)