[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [StartActivity](index.md) / [workoutExercise](./workout-exercise.md)

# workoutExercise

`var workoutExercise: `[`ArrayList`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-array-list/index.html)`<`[`Exercise`](../../com.mateusz.workoutcustomer.database/-exercise/index.md)`>`