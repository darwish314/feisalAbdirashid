[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseAdapter](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseAdapter(context: `[`Context`](https://developer.android.com/reference/android/content/Context.html)`)`

class ExerciseAdapter extends from RecycleView.Adapter and it is for RecycleView

