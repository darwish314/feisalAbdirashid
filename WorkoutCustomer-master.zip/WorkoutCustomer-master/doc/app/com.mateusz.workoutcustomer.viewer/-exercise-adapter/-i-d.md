[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseAdapter](index.md) / [ID](./-i-d.md)

# ID

`const val ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is string which stores id address. This address is for intent can put ID. This property is companion object because ExerciseViewActivity must have address for read data

### Property

`ID` - is string which stores id address. This address is for intent can put ID. This property is companion object because ExerciseViewActivity must have address for read data

**Author**
Mateusz Karłowski

