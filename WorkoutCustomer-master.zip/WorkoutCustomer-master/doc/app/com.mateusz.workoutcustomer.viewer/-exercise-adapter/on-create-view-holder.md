[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseAdapter](index.md) / [onCreateViewHolder](./on-create-view-holder.md)

# onCreateViewHolder

`fun onCreateViewHolder(parent: `[`ViewGroup`](https://developer.android.com/reference/android/view/ViewGroup.html)`, p1: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`ExerciseViewHolder`](-exercise-view-holder/index.md)

onCreateViewHolder find CardView in layout and return items look like R.layout.exercise_item with data

