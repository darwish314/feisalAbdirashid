[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseAdapter](index.md) / [setList](./set-list.md)

# setList

`fun setList(list: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Exercise`](../../com.mateusz.workoutcustomer.database/-exercise/index.md)`>): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

function setList set new List with new Data

