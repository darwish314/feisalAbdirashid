[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseViewHolder(viewItem: `[`View`](https://developer.android.com/reference/android/view/View.html)`, exerciseAdapter: `[`ExerciseAdapter`](../index.md)`)`

sets OnClick as OnClickListener

**Constructor**
sets OnClick as OnClickListener

