[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [mExerciseDescription](./m-exercise-description.md)

# mExerciseDescription

`var mExerciseDescription: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)

is TextView with exercise Description.

### Property

`mExerciseDescription` - is TextView with exercise Description.