[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [mExerciseTitle](./m-exercise-title.md)

# mExerciseTitle

`var mExerciseTitle: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)

is TextView with exercise Title

### Property

`mExerciseTitle` - is TextView with exercise Title