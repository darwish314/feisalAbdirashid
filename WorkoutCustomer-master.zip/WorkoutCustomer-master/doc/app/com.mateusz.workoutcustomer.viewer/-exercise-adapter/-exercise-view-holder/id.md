[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [id](./id.md)

# id

`var id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

is workout id

### Property

`id` - is workout id