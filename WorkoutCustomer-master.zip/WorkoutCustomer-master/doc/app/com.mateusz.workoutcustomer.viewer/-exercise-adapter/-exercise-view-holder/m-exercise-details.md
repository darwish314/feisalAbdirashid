[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [mExerciseDetails](./m-exercise-details.md)

# mExerciseDetails

`var mExerciseDetails: `[`TextView`](https://developer.android.com/reference/android/widget/TextView.html)

is TextView with exercise Details

### Property

`mExerciseDetails` - is TextView with exercise Details