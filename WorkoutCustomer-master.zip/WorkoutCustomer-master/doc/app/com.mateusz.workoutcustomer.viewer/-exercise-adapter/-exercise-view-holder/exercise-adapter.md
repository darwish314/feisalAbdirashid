[app](../../../index.md) / [com.mateusz.workoutcustomer.viewer](../../index.md) / [ExerciseAdapter](../index.md) / [ExerciseViewHolder](index.md) / [exerciseAdapter](./exercise-adapter.md)

# exerciseAdapter

`var exerciseAdapter: `[`ExerciseAdapter`](../index.md)