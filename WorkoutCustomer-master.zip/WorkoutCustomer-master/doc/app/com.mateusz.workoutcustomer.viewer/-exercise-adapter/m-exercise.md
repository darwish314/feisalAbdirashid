[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseAdapter](index.md) / [mExercise](./m-exercise.md)

# mExercise

`lateinit var mExercise: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Exercise`](../../com.mateusz.workoutcustomer.database/-exercise/index.md)`>`

is list Workout

### Property

`mExercise` - is list Workout

**See Also**

[Exercise](../../com.mateusz.workoutcustomer.database/-exercise/index.md)

