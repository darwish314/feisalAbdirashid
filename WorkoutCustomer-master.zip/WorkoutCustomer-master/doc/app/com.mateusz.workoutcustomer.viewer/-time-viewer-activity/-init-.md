[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [TimeViewerActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`TimeViewerActivity()`

It see exercise with time

