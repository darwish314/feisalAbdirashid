[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [TimeViewerActivity](index.md) / [pauseFormat](./pause-format.md)

# pauseFormat

`const val pauseFormat: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

is address where intent put data and where activity get data. Address have information about pause format

### Property

`pauseFormat` - is address where intent put data and where activity get data. Address have information about pause format