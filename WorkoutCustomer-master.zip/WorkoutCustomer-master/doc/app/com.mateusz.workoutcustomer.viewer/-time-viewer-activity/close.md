[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [TimeViewerActivity](index.md) / [close](./close.md)

# close

`var close: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

is bool when is true this activity is finish

### Property

`close` - is bool when is true this activity is finish