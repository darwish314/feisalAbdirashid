[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseViewActivity](index.md) / [id](./id.md)

# id

`var id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

is current exercise id

### Property

`id` - is current exercise id

**Author**
Mateusz Karłowski

