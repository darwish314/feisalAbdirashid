[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [ExerciseViewActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ExerciseViewActivity()`

This shows data about selected exercise

