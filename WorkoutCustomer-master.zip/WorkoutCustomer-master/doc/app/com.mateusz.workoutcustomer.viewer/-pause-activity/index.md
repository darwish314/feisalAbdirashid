[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [PauseActivity](./index.md)

# PauseActivity

`class PauseActivity : AppCompatActivity`

### Constructors

| [&lt;init&gt;](-init-.md) | `PauseActivity()` |

### Properties

| [close](close.md) | `var close: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) |

### Functions

| [onBackPressed](on-back-pressed.md) | `fun onBackPressed(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html) |
| [onCreate](on-create.md) | `fun onCreate(savedInstanceState: `[`Bundle`](https://developer.android.com/reference/android/os/Bundle.html)`?): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html) |
| [stopPause](stop-pause.md) | `fun stopPause(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html) |

