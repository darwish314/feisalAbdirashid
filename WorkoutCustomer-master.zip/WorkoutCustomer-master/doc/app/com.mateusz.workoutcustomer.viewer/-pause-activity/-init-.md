[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [PauseActivity](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`PauseActivity()`