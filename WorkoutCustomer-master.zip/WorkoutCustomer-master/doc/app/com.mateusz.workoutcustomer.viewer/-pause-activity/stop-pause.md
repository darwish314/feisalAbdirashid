[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [PauseActivity](index.md) / [stopPause](./stop-pause.md)

# stopPause

`fun stopPause(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)