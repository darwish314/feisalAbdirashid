[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [RepeatViewerActivity](index.md) / [pause](./pause.md)

# pause

`fun pause(view: `[`View`](https://developer.android.com/reference/android/view/View.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

This function stops counting down across set close to true.
Next function creates new intent and start it

