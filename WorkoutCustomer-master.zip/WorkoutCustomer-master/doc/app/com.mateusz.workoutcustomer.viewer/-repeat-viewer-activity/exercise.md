[app](../../index.md) / [com.mateusz.workoutcustomer.viewer](../index.md) / [RepeatViewerActivity](index.md) / [exercise](./exercise.md)

# exercise

`lateinit var exercise: `[`Exercise`](../../com.mateusz.workoutcustomer.database/-exercise/index.md)

is current exercise object

### Property

`exercise` - is current exercise object

**Author**
Mateusz Karłowski

