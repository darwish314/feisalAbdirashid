#Workout Customer
## Idea
Almost all **mobile applications** to workout has ready sets of exercises. 
I didn't find app for people who know some information about workout and they want make own set. 
That is what my application different other similar app. 
You'll be able to **make customize set workout** with image, video etc. You forget to remember exercises.
You will have everything on your smartphone.