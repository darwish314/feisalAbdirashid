# Dear readers
## You can contributing my app. If you did it I will be very happy. I have some pro tips for this:
1. Use Kotlin as much as possible
2. You must observe license
3. I use Android Studio. You also can. It's free
4. Please try to make the layout responsive
