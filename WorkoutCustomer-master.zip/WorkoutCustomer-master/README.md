# Workout Customer
Workout Customer is **Mobile App for Android** where you can create **custom** training.
## application look
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/menu-view.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/creator-workout.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/repeat-view.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/exercise-repeat-creator.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/exercise-time-creator.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/exercise-view.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/pause-view.png) 
![Workout Creator](https://github.com/mati2251/WorkoutCustomer/blob/master/.github/Screen%20/view-workout.png)
## Installation
[Download Link](https://drive.google.com/open?id=1MBW2nbjt_jH-URsYbYJkYYTO-h1LfyuY). App will be on play store
## License
**GNU General Public License v3.0** [License Link](https://github.com/mati2251/WorkoutCustomer/blob/master/LICENSE)